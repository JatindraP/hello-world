flume-ng agent --conf conf --conf-file bicycle.conf --name bicycle -Dflume.root.logger=INFO,console
