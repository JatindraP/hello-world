#spark2-submit --master yarn --deploy-mode client --class BicycleSharing /mnt/home/edureka_1047469/project/target/scala-2.11/edurekaassignment_2.11-0.1.jar
#spark2-submit --master yarn --deploy-mode client --class PredictPopularity /mnt/home/edureka_1047469/project/target/scala-2.11/edurekaassignment_2.11-0.1.jar
spark2-submit --master yarn --deploy-mode client --class PredictFlumeData /mnt/home/edureka_1047469/project/target/scala-2.11/edurekaassignment_2.11-0.1.jar
