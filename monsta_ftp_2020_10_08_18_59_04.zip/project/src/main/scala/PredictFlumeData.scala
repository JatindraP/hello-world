import org.apache.spark.SparkConf
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.regression.LinearRegressionModel
import org.apache.spark.sql.SQLContext
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.sql.functions._
//Used for Second(2) function
import org.apache.spark.streaming._

object PredictFlumeData {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("Predict flume data")
    val ssc = new StreamingContext(conf, Seconds(2))
    val lines = ssc.textFileStream("/user/edureka_1047469/project/flume/" + java.time.LocalDate.now)
    val df =lines.map(row=>row.split(",")).map(row=>Feature(row(0).toString,
      row(1).toInt,
      row(2).toInt,
      row(3).toInt,
      row(4).toInt,
      row(5).toDouble,
      row(6).toDouble,
      row(7).toInt,
      row(8).toDouble))
    df.foreachRDD { rdd =>
      val sqlContext = new SQLContext(rdd.sparkContext)
      import sqlContext.implicits._
      val dataDf=rdd.toDF()
      val explodDataDf=dataDf.withColumn("season_1",(col("season")===1).cast("int"))
        .withColumn("season_2",(col("season")===2).cast("int"))
        .withColumn("season_3",(col("season")===3).cast("int"))
        .withColumn("season_4",(col("season")===4).cast("int")).drop("season")
        .withColumn("weather_1",(col("weather")===1).cast("int"))
        .withColumn("weather_2",(col("weather")===2).cast("int"))
        .withColumn("weather_3",(col("weather")===3).cast("int"))
        .withColumn("weather_4",(col("weather")===4).cast("int")).drop("weather").drop("datetime")
      val model = LinearRegressionModel.read.load("/user/edureka_1047469/project/scalaML.model")
      val inputCols=Array("holiday","workingday","temp","atemp","humidity","windspeed","season_1","season_2","season_3","season_4","weather_1","weather_2","weather_3","weather_4")
      val assembler = new VectorAssembler().setInputCols(inputCols).setOutputCol("features")
      val featureDF = assembler.transform(explodDataDf).select($"features")
      val predictions=model.transform(featureDF)
      println(predictions.show(1))
    }

    ssc.start()
    ssc.awaitTermination()

  }

}
