case class Data(datetime:String, season:Int, holiday:Int, workingday:Int,
                weather:Int, temp:Double, atemp:Double, humidity:Int, windspeed:Double,
                casual:Int, registered:Int, count:Int)
