import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.regression.LinearRegression


object BicycleSharing {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("Bucycle Sharing")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val bicycleRaw = spark.read.text("/user/edureka_1047469/project/data/train.csv")
    val head=bicycleRaw.first()
    val bicycleRawData = bicycleRaw.filter(row=>row != head)
    import spark.implicits._
    val bicycleDf=bicycleRawData.map(row=>row.getString(0).split(",")).map(row=>Data(
      row(0).toString,
      row(1).toInt,
      row(2).toInt,
      row(3).toInt,
      row(4).toInt,
      row(5).toDouble,
      row(6).toDouble,
      row(7).toInt,
      row(8).toDouble,
      row(9).toInt,
      row(10).toInt,
      row(11).toInt
    )).toDF()
    // Handelling the Missing value
    val nullcounts = bicycleDf.select(bicycleDf.columns.map(c => sum(col(c).isNull.cast("int")).alias(c)):_*)
    val totcount = bicycleDf.count
    nullcounts.first().toSeq.zip(bicycleDf.columns).map(x=>(x._1, "%1.2f".format(x._1.toString.toDouble*100/totcount), x._2)).foreach(println)
    //Explode season column into separate columns such as season_<val> and drop season
    val explodBicycleDf=bicycleDf.withColumn("season_1",(col("season")===1).cast("int"))
        .withColumn("season_2",(col("season")===2).cast("int"))
        .withColumn("season_3",(col("season")===3).cast("int"))
        .withColumn("season_4",(col("season")===4).cast("int")).drop("season")
        .withColumn("weather_1",(col("weather")===1).cast("int"))
        .withColumn("weather_2",(col("weather")===2).cast("int"))
        .withColumn("weather_3",(col("weather")===3).cast("int"))
        .withColumn("weather_4",(col("weather")===4).cast("int")).drop("weather")
    val newBicycleDF=explodBicycleDf.withColumn("year",year(trim(col("datetime"))))
        .withColumn("month",month(trim(col("datetime"))))
        .withColumn("day",dayofyear(trim(col("datetime"))))
        .withColumn("hour",hour(trim(col("datetime"))))
    newBicycleDF.cache()
    newBicycleDF.groupBy("year").agg(sum("count")).show()
    newBicycleDF.groupBy("year","month").agg(sum("count")).show()
    newBicycleDF.groupBy("year","month","day").agg(sum("count")).show()
    newBicycleDF.groupBy("year","month","day","hour").agg(sum("count")).show()
    val bicycleDfMl=newBicycleDF.select("count","holiday","workingday","temp","atemp","humidity","windspeed","season_1","season_2","season_3","season_4","weather_1","weather_2","weather_3","weather_4")
      .withColumnRenamed("count","label")
    val inputCols=Array("holiday","workingday","temp","atemp","humidity","windspeed","season_1","season_2","season_3","season_4","weather_1","weather_2","weather_3","weather_4")
    val assembler = new VectorAssembler().setInputCols(inputCols).setOutputCol("features")
    val featureDF = assembler.transform(bicycleDfMl).select($"label",$"features")
    featureDF.show()
    val lr = new LinearRegression()
    val lrModel = lr.fit(featureDF)
    println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")
    lrModel.write.overwrite().save("/user/edureka_1047469/project/scalaML.model")


       spark.stop()
  }

}
