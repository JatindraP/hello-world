case class Feature(datetime:String, season:Int, holiday:Int, workingday:Int,
                   weather:Int, temp:Double, atemp:Double, humidity:Int, windspeed:Double)
